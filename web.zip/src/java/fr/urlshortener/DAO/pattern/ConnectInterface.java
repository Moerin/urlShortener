/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package fr.urlshortener.DAO.pattern;

/**
 *
 * @author Sebastien
 */
public interface ConnectInterface {
    
    public void start();
    
    public void stop();
    
    public void restart();
    
}
