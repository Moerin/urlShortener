/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package fr.urlshortener.DAO.pattern;

/**
 *
 * @author Sebastien
 */
public interface QueryInterface {
    
    /**
     *
     * @param obj
     * @param obj
     * @return
     */
    public Object query(Object obj1, Object obj2); // TODO : developper cette methode pour qu'elle permette de gere les requetes particulieres
    
}
